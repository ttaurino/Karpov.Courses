# karpov.courses
Домашние задания по курсу "Аналитик данных" от Анатолия Карпова https://karpov.courses/analytics
